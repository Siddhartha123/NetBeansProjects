
import java.sql.Connection;
import java.sql.SQLException;


public class Main {
    public static void main(String[] args)  throws SQLException, ClassNotFoundException, InterruptedException, CloneNotSupportedException {
        jdbc_con db;
        db = new jdbc_con("com.mysql.jdbc.Driver","jdbc:mysql://localhost/cyborg","root","");
        if(db.is_connected){
            Connection con=db.getConnection(db);
            Object con1=(Object)con;
            Poolnew p=new Poolnew(7,con1);
            p.getPoolObject(5000);
            p.getPoolObject(10000);
            p.getPoolObject(15000);
            p.getPoolObject(13000);
            p.getPoolObject(7000);
            p.getPoolObject(17000);
            p.getPoolObject(9000);
            p.getPoolObject(16000);
            p.getPoolObject(20000);

            //p.executor.shutdown();
            /*while (!p.executor.isTerminated()) {
            }*/
    }
    }
}
